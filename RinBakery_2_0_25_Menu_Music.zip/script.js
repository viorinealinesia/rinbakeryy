const products=[
["Chocolate Cake","185000","https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"],
["Strawberry Cupcake","35000","https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=800&q=88"],
["Red Velvet","160000","https://images.unsplash.com/photo-1586788224331-947f68671cf1?auto=format&fit=crop&w=800&q=88"],
["Blueberry Cheesecake","150000","https://images.unsplash.com/photo-1571115177098-24ec42ed204d?auto=format&fit=crop&w=800&q=88"],
["Matcha Cake","175000","https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=800&q=88"],
["Tiramisu Cake","185000","https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=800&q=88"],
["Black Forest Cake","180000","https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"],
["Lotus Biscoff Cake","195000","https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"],
["Vanilla Berry Cake","175000","https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?auto=format&fit=crop&w=800&q=88"],
["Strawberry Shortcake","180000","https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=800&q=88"],
["Lemon Cake","165000","https://images.unsplash.com/photo-1519915028121-7d3463d20b13?auto=format&fit=crop&w=800&q=88"],
["Carrot Cake","170000","https://images.unsplash.com/photo-1571115177098-24ec42ed204d?auto=format&fit=crop&w=800&q=88"],
["Fudgy Brownies","85000","https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=88"],
["Cheese Brownies","95000","https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=800&q=88"],
["Nutella Brownies","100000","https://images.unsplash.com/photo-1575377427642-087cf684f04d?auto=format&fit=crop&w=800&q=88"],
["Choco Chip Cookies","70000","https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=800&q=88"],
["Red Velvet Cookies","75000","https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=800&q=88"],
["Biscoff Cookies","80000","https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=800&q=88"],
["Butter Croissant","35000","https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=88"],
["Cinnamon Roll","40000","https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=800&q=88"],
["Fruit Tart","45000","https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&w=800&q=88"],
["Mini Cupcake","55000","https://images.unsplash.com/photo-1587668178277-295251f900ce?auto=format&fit=crop&w=800&q=88"],
["Pudding Cake","65000","https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=800&q=88"],
["Cheese Cake","175000","https://images.unsplash.com/photo-1571115177098-24ec42ed204d?auto=format&fit=crop&w=800&q=88"],
["Vanilla Cake","165000","https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"]
];
const grid=document.getElementById("menuGrid");
products.forEach(p=>{
  const card=document.createElement("article"); card.className="menuCard";
  card.innerHTML=`<img src="${p[2]}" alt="${p[0]}"><div><h3>${p[0]}</h3><p>Rp${Number(p[1]).toLocaleString("id-ID")}</p><button>Pesan Menu</button></div>`;
  card.querySelector("button").onclick=()=>window.open("https://wa.me/6283128844922?text="+encodeURIComponent(`Halo RinBakery, saya ingin pesan ${p[0]} seharga Rp${Number(p[1]).toLocaleString("id-ID")}.`),"_blank");
  grid.appendChild(card);
});

const bakeryMusic=document.getElementById("bakeryMusic"),musicToggle=document.getElementById("musicToggle"),musicPlayer=document.getElementById("musicPlayer");musicToggle.onclick=async()=>{if(bakeryMusic.paused){await bakeryMusic.play();musicToggle.textContent="Ⅱ";musicPlayer.classList.add("playing")}else{bakeryMusic.pause();musicToggle.textContent="♫";musicPlayer.classList.remove("playing")}};
