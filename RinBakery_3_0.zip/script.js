const P=[
["Chocolate Cake","Cake",185000,"https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"],
["Strawberry Cupcake","Cake",35000,"https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=800&q=88"],
["Red Velvet","Cake",160000,"https://images.unsplash.com/photo-1586788224331-947f68671cf1?auto=format&fit=crop&w=800&q=88"],
["Blueberry Cheesecake","Cake",150000,"https://images.unsplash.com/photo-1571115177098-24ec42ed204d?auto=format&fit=crop&w=800&q=88"],
["Matcha Cake","Cake",175000,"https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=800&q=88"],
["Tiramisu Cake","Cake",185000,"https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=800&q=88"],
["Black Forest Cake","Cake",180000,"https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"],
["Lotus Biscoff Cake","Cake",195000,"https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"],
["Vanilla Berry Cake","Cake",175000,"https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?auto=format&fit=crop&w=800&q=88"],
["Strawberry Shortcake","Cake",180000,"https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=800&q=88"],
["Lemon Cake","Cake",165000,"https://images.unsplash.com/photo-1519915028121-7d3463d20b13?auto=format&fit=crop&w=800&q=88"],
["Carrot Cake","Cake",170000,"https://images.unsplash.com/photo-1571115177098-24ec42ed204d?auto=format&fit=crop&w=800&q=88"],
["Fudgy Brownies","Brownies",85000,"https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=88"],
["Cheese Brownies","Brownies",95000,"https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=800&q=88"],
["Nutella Brownies","Brownies",100000,"https://images.unsplash.com/photo-1575377427642-087cf684f04d?auto=format&fit=crop&w=800&q=88"],
["Choco Chip Cookies","Cookies",70000,"https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=800&q=88"],
["Red Velvet Cookies","Cookies",75000,"https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=800&q=88"],
["Biscoff Cookies","Cookies",80000,"https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=800&q=88"],
["Butter Croissant","Pastry",35000,"https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=88"],
["Cinnamon Roll","Pastry",40000,"https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=800&q=88"],
["Fruit Tart","Dessert",45000,"https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&w=800&q=88"],
["Mini Cupcake","Dessert",55000,"https://images.unsplash.com/photo-1587668178277-295251f900ce?auto=format&fit=crop&w=800&q=88"],
["Pudding Cake","Dessert",65000,"https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=800&q=88"],
["Cheese Cake","Cake",175000,"https://images.unsplash.com/photo-1571115177098-24ec42ed204d?auto=format&fit=crop&w=800&q=88"],
["Vanilla Cake","Cake",165000,"https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=88"]];
let cart=[];
const money=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
const products=document.getElementById("products");
function draw(list=P){products.innerHTML=list.map((p,i)=>`<article class="product"><img src="${p[3]}" alt="${p[0]}"><div class="info"><span class="tag">${p[1].toUpperCase()}</span><h3>${p[0]}</h3><p>Freshly baked dengan rasa lembut dan premium.</p><div class="price"><b>${money(p[2])}</b><button class="add" data-i="${P.indexOf(p)}">+ Keranjang</button></div></div></article>`).join("");document.querySelectorAll(".add").forEach(b=>b.onclick=()=>add(+b.dataset.i))}
function add(i){let x=cart.find(x=>x.i===i);x?x.q++:cart.push({i,q:1});renderCart()}
function renderCart(){document.getElementById("cartCount").textContent=cart.reduce((a,x)=>a+x.q,0);document.getElementById("cartItems").innerHTML=cart.length?cart.map((x,n)=>{let p=P[x.i];return `<div class="cart-row"><img src="${p[3]}"><div><b>${p[0]}</b><small>${money(p[2])} × ${x.q}</small></div><button class="remove" onclick="removeCart(${n})">Hapus</button></div>`}).join(""):"<p style='color:#888;text-align:center;padding:30px'>Keranjang masih kosong ♡</p>";document.getElementById("cartTotal").textContent=money(cart.reduce((a,x)=>a+P[x.i][2]*x.q,0))}
function removeCart(n){cart.splice(n,1);renderCart()}
document.querySelectorAll(".filters button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");let c=b.dataset.cat;draw(c==="Semua"?P:P.filter(x=>x[1]===c))});
document.getElementById("search").oninput=e=>{let q=e.target.value.toLowerCase();draw(P.filter(x=>x[0].toLowerCase().includes(q)))};
cartBtn.onclick=()=>drawerBg.classList.add("show");closeCart.onclick=()=>drawerBg.classList.remove("show");
checkout.onclick=()=>{if(!cart.length)return alert("Keranjang masih kosong.");let t="Halo RinBakery, saya ingin checkout:%0A"+cart.map(x=>`• ${P[x.i][0]} x${x.q}`).join("%0A")+"%0ATotal: "+money(cart.reduce((a,x)=>a+P[x.i][2]*x.q,0));window.open("https://wa.me/6283128844922?text="+encodeURIComponent(t),"_blank")};
customSend.onclick=()=>{let t=`Halo RinBakery, saya ingin custom cake.%0ANama: ${custName.value||"-"}%0AUkuran: ${custSize.value}%0ARasa: ${custFlavor.value}%0ACatatan: ${custNote.value||"-"}`;window.open("https://wa.me/6283128844922?text="+encodeURIComponent(t),"_blank")};
searchBtn.onclick=()=>{document.getElementById("search").focus();location.hash="menu"};
const music=document.getElementById("music"),musicToggle=document.getElementById("musicToggle");musicToggle.onclick=async()=>{if(music.paused){await music.play();musicToggle.textContent="Ⅱ"}else{music.pause();musicToggle.textContent="♫"}};
draw();renderCart();
