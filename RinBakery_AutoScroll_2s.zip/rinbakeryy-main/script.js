// ===============================
// NAVBAR SCROLL EFFECT
// ===============================

const navbar = document.getElementById("navbar");

window.addEventListener("scroll", () => {

  if (window.scrollY > 20) {
    navbar.classList.add("scrolled");
  } else {
    navbar.classList.remove("scrolled");
  }

});


// ===============================
// MOBILE MENU
// ===============================

const toggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

toggle.addEventListener("click", () => {

  navLinks.classList.toggle("mobile");

  if (navLinks.classList.contains("mobile")) {

    toggle.textContent = "×";

  } else {

    toggle.textContent = "☰";

  }

});


// ===============================
// CLOSE MOBILE MENU
// ===============================

document
  .querySelectorAll(".nav-links a")
  .forEach(link => {

    link.addEventListener("click", () => {

      navLinks.classList.remove("mobile");

      toggle.textContent = "☰";

    });

  });


// ===============================
// SCROLL REVEAL ANIMATION
// ===============================

const observer =
  new IntersectionObserver(

    (entries) => {

      entries.forEach(entry => {

        if (entry.isIntersecting) {

          entry.target.classList.add("show");

          observer.unobserve(entry.target);

        }

      });

    },

    {
      threshold: 0.12
    }

  );


document
  .querySelectorAll(".reveal")
  .forEach(element => {

    observer.observe(element);

  });


// ===============================
// PRODUCT HEART
// ===============================

const hearts =
  document.querySelectorAll(".product-info > div span");

hearts.forEach(heart => {

  heart.style.cursor = "pointer";

  heart.addEventListener("click", () => {

    if (heart.textContent === "♡") {

      heart.textContent = "♥";

      heart.style.color = "#d7869d";

    } else {

      heart.textContent = "♡";

      heart.style.color = "";

    }

  });

});

// ===============================
// AUTO SCROLL AFTER USER INACTIVITY
// ===============================
// Setelah 2 detik tanpa interaksi user, halaman akan scroll pelan
// ke bawah. Saat mencapai bagian paling bawah, halaman langsung
// kembali ke atas lalu melanjutkan auto-scroll dari awal.
// Interaksi user akan menghentikan sementara auto-scroll dan timer
// akan dimulai lagi setelah interaksi selesai.

const AUTO_SCROLL_DELAY = 2000; // 2 detik
const AUTO_SCROLL_SPEED = 0.65; // pixel per frame (pelan)

let autoScrollTimer = null;
let autoScrollFrame = null;
let autoScrolling = false;

function stopAutoScroll() {
  autoScrolling = false;

  if (autoScrollTimer) {
    clearTimeout(autoScrollTimer);
    autoScrollTimer = null;
  }

  if (autoScrollFrame) {
    cancelAnimationFrame(autoScrollFrame);
    autoScrollFrame = null;
  }
}

function startAutoScrollTimer() {
  stopAutoScroll();

  autoScrollTimer = setTimeout(() => {
    autoScrolling = true;
    autoScrollFrame = requestAnimationFrame(autoScrollStep);
  }, AUTO_SCROLL_DELAY);
}

function autoScrollStep() {
  if (!autoScrolling) return;

  const maxScroll =
    document.documentElement.scrollHeight - window.innerHeight;

  // Jika sudah sampai bawah, langsung kembali ke paling atas.
  if (window.scrollY >= maxScroll - 2) {
    window.scrollTo(0, 0);

    // Lanjutkan auto-scroll pelan dari atas.
    autoScrollFrame = requestAnimationFrame(autoScrollStep);
    return;
  }

  window.scrollBy(0, AUTO_SCROLL_SPEED);
  autoScrollFrame = requestAnimationFrame(autoScrollStep);
}

// Aktivitas user yang dianggap sebagai interaksi.
// Scroll programatis dari auto-scroll TIDAK memanggil fungsi ini.
[
  "wheel",
  "touchstart",
  "touchmove",
  "mousedown",
  "pointerdown",
  "keydown"
].forEach(eventName => {
  window.addEventListener(eventName, () => {
    startAutoScrollTimer();
  }, { passive: true });
});

// Klik link/navbar juga dianggap aktivitas user.
document.addEventListener("click", () => {
  startAutoScrollTimer();
});

// Mulai menghitung 2 detik sejak halaman selesai dimuat.
window.addEventListener("load", () => {
  startAutoScrollTimer();
});
